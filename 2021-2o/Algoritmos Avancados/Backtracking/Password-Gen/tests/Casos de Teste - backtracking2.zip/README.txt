Arquivo zip gerado em: 17/09/2021 12:18:02 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: backtracking2